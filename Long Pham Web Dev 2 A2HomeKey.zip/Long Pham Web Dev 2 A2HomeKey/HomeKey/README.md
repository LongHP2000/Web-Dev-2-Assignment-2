# HomeKey

HomeKey is a simple React, Vite and Express university web project for browsing properties for sale.

## Features
- 8 fictional London property listings with images
- Filter by location, price and bedrooms
- Property details and features
- Register, login and logout
- Save favourite properties
- Request a property viewing
- My Account with saved properties and viewing requests
- Responsive desktop and mobile layout

## Run the project
Open two terminals.

### Terminal 1 - server
```bash
cd server
npm install
npm run dev
```

### Terminal 2 - client
```bash
cd client
npm install
npm run dev
```

Open the Vite address shown in the client terminal, normally http://localhost:5173.

## Note
Accounts, saved properties and viewing appointments are stored in server/data/accounts.json and survive server restarts. Keep this file when updating the project. Passwords are hashed. Log in again after a server restart. Each account sees its own records. Viewing dates must be in the future. Existing records from the old in-memory version cannot be recovered after stopping that version.

## From the HomeKey folder
Install once: `npm --prefix client install` and `npm --prefix server install`.
Run `npm run server` in one terminal and `npm run client` in another.

Register an email account, log in, open a property and click Save Property. Select a future date and time and click Send Request. My Account shows the email, saved properties and appointments. These are website accounts; this project does not create an email mailbox or send confirmation emails.
