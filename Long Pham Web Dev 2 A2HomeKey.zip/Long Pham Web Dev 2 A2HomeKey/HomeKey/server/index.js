import express from 'express';
import cors from 'cors';
import { randomBytes, createHash } from 'crypto';
import bcrypt from 'bcryptjs';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const app=express();
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const properties=JSON.parse(fs.readFileSync(path.join(__dirname,'data/properties.json')));
const storePath=path.join(__dirname,'data/accounts.json');
const store=fs.existsSync(storePath)?JSON.parse(fs.readFileSync(storePath,'utf8')):{users:[],viewings:[],favourites:[]};
const {users,viewings,favourites}=store;
const persist=()=>{const tmp=storePath+'.tmp';fs.writeFileSync(tmp,JSON.stringify(store,null,2));fs.renameSync(tmp,storePath)};
const sessions=new Map();
const authenticate=(req,res,next)=>{const token=req.headers.authorization?.replace(/^Bearer /,'');const id=sessions.get(token);if(!id)return res.status(401).json({message:'Please log in again.'});req.userId=id;next()};
app.use(cors());app.use(express.json());
app.get('/api/properties',(req,res)=>res.json(properties));
app.get('/api/properties/:id',(req,res)=>{const p=properties.find(x=>x.id===Number(req.params.id));p?res.json(p):res.status(404).json({message:'Property not found'})});
app.post('/api/register',async(req,res)=>{const{name,password}=req.body;const email=typeof req.body.email==='string'?req.body.email.trim().toLowerCase():'';if(!name||!email||!password)return res.status(400).json({message:'Please complete all fields'});if(typeof name!=='string'||typeof password!=='string'||!/^\S+@\S+\.\S+$/.test(email))return res.status(400).json({message:'Please enter a valid name, email and password'});if(password.length<6)return res.status(400).json({message:'Password must be at least 6 characters'});if(users.some(u=>u.email===email.toLowerCase()))return res.status(409).json({message:'Email already registered'});users.push({id:users.length+1,name,email:email.toLowerCase(),password:await bcrypt.hash(password,10)});persist();res.status(201).json({message:'Account created. You can now log in.'})});
app.post('/api/login',async(req,res)=>{const user=users.find(u=>u.email===(typeof req.body.email==='string'?req.body.email.trim().toLowerCase():''));if(!user||!(await bcrypt.compare(req.body.password||'',user.password)))return res.status(401).json({message:'Incorrect email or password'});const token=randomBytes(32).toString('hex');sessions.set(token,user.id);res.json({id:user.id,name:user.name,email:user.email,token})});
// Local demonstration delivery: reset codes are printed only to the server terminal.
const resetTokens=new Map(),resetRequests=new Map();
const digestReset=value=>createHash('sha256').update(value).digest('hex');
app.post('/api/forgot-password',(req,res)=>{
 const address=req.socket.remoteAddress;
 if(!['127.0.0.1','::1','::ffff:127.0.0.1'].includes(address))return res.status(403).json({message:'Local password recovery is available only on this computer.'});
 const email=typeof req.body.email==='string'?req.body.email.trim().toLowerCase():'';
 if(!/^\S+@\S+\.\S+$/.test(email))return res.status(400).json({message:'Enter a valid email address.'});
 const now=Date.now();const recent=(resetRequests.get(address)||[]).filter(time=>now-time<15*60*1000);
 if(recent.length>=5)return res.status(429).json({message:'Too many reset requests. Try again in 15 minutes.'});
 resetRequests.set(address,[...recent,now]);
 const user=users.find(u=>u.email===email);
 if(user){const code=randomBytes(24).toString('hex');resetTokens.set(user.id,{hash:digestReset(code),expires:now+10*60*1000});console.log(`HomeKey local password reset for ${email}: ${code} (expires in 10 minutes)`)}
 res.json({message:'If that email is registered, a reset code is available in the server terminal. It expires in 10 minutes.'});
});
app.post('/api/reset-password',async(req,res)=>{
 const email=typeof req.body.email==='string'?req.body.email.trim().toLowerCase():'';
 const {code,password,confirmPassword}=req.body;
 if(typeof password!=='string'||password.length<6||password.length>72)return res.status(400).json({message:'Use a password of 6 to 72 characters.'});
 if(password!==confirmPassword)return res.status(400).json({message:'Passwords do not match.'});
 const user=users.find(u=>u.email===email),entry=user&&resetTokens.get(user.id);
 if(typeof code!=='string'||!entry||entry.expires<=Date.now()||entry.hash!==digestReset(code.trim()))return res.status(400).json({message:'Invalid or expired reset code. Request a new code.'});
 // Consume before awaiting password hashing so concurrent attempts cannot reuse the code.
 resetTokens.delete(user.id);user.password=await bcrypt.hash(password,10);persist();
 for(const [token,id] of sessions){if(id===user.id)sessions.delete(token)}
 res.json({message:'Password reset successfully. Log in with your new password.'});
});
app.post('/api/favourites',authenticate,(req,res)=>{const userId=req.userId,propertyId=Number(req.body.propertyId);if(!properties.some(p=>p.id===propertyId))return res.status(400).json({message:'Invalid property'});if(favourites.some(f=>f.userId===userId&&f.propertyId===propertyId))return res.json({message:'Property is already saved'});favourites.push({id:favourites.length+1,userId,propertyId,savedAt:new Date().toISOString()});persist();res.status(201).json({message:'Property saved'})});
app.delete('/api/favourites/:propertyId',authenticate,(req,res)=>{const propertyId=Number(req.params.propertyId);const index=favourites.findIndex(f=>f.userId===req.userId&&f.propertyId===propertyId);if(index!==-1){favourites.splice(index,1);persist()}res.json({message:'Property removed from saved properties'})});
app.get('/api/favourites/:userId',authenticate,(req,res)=>res.json(favourites.filter(f=>f.userId===req.userId)));
app.post('/api/viewings',authenticate,(req,res)=>{const {date,time}=req.body;if(!properties.some(p=>p.id===Number(req.body.propertyId))||!/^\d{4}-\d{2}-\d{2}$/.test(date||'')||!/^([01]\d|2[0-3]):[0-5]\d$/.test(time||'')||!Number.isFinite(new Date(date+'T'+time).getTime())||new Date(date+'T'+time)<=new Date())return res.status(400).json({message:'Choose a valid property and a future appointment date and time.'});const item={id:viewings.length+1,userId:req.userId,propertyId:Number(req.body.propertyId),date:req.body.date,time:req.body.time,status:'Requested',requestedAt:new Date().toISOString()};viewings.push(item);if(!favourites.some(f=>f.userId===req.userId&&f.propertyId===item.propertyId))favourites.push({id:favourites.length+1,userId:req.userId,propertyId:item.propertyId,savedAt:new Date().toISOString()});persist();res.status(201).json(item)});
app.get('/api/viewings/:userId',authenticate,(req,res)=>res.json(viewings.filter(v=>v.userId===req.userId)));
app.get('/api/me',authenticate,(req,res)=>{const user=users.find(u=>u.id===req.userId);res.json({id:user.id,name:user.name,email:user.email})});
app.post('/api/logout',authenticate,(req,res)=>{sessions.delete(req.headers.authorization.replace(/^Bearer /,''));res.json({message:'Logged out'})});
app.listen(Number(process.env.PORT)||3000,()=>console.log('HomeKey server running on http://localhost:3000'));
